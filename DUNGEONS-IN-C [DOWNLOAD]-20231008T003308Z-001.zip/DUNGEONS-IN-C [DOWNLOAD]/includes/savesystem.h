#ifndef SAVESYSTEM_H
#define SAVESYSTEM_H
#include "../includes/config.h"
void SalvarPlayer(Player *player, int i, Item itens[]);
int AbrirSave(Player *player);
#endif